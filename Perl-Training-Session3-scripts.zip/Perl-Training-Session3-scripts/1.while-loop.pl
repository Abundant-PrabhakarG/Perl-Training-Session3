use strict;
use warnings;

my $a = 10;

while( $a < 20 ) {
   print "Value of a: $a\n";
   $a = $a + 1;
}