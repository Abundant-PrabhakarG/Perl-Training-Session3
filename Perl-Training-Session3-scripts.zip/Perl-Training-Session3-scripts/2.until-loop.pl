use strict;
use warnings;

my $a = 5;

until( $a > 10 ) {
   print "Value of a: $a\n";
   $a = $a + 1;
}