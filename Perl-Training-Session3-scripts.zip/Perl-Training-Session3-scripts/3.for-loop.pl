use strict;
use warnings;

for( $a = 10; $a < 20; $a = $a + 1 ) 
#for( $a = 10; $a < 20; $a++ ) 
   {
   print "value of a: $a\n";
   }