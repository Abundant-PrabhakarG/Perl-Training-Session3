use strict;
use warnings; 

open(DATA1, "<import.txt"); # Open file to read
open(DATA2, ">file2.txt"); # Open new file to write
my @file = <DATA1>;
foreach my $line (@file) {
   if($line =~ /^Data.*/)
     {
     print DATA2 "$line";
     print $line;
     }
}
close( DATA1 );
close( DATA2 );
