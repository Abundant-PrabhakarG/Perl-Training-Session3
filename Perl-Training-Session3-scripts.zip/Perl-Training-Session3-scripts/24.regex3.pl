 use strict;
 use warnings;
 
 my $mystring = "Hello World!";
 if($mystring =~ m/World/) 
   { 
   print "***Yes\n"; 
   }
 
 #Ignoring case
 if($mystring =~ m/world/i) 
   { 
   print "---Yes\n"; 
  }