use strict;
use warnings;

my $str = 'The dog jumped from the green tree';
if ($str =~ /^The.*/) 
   {
    print "The first word is *****The*****\n";
   }
   
if ($str =~ /^The.*tree$/) 
   {
    #print "The last word is .....tree.....\n";
   }

my $spstr1 = '#The dog jumped from the green tree';   

if ($spstr1 =~ /(\#)The.*tree/) 
   {
    #print "The special character that exists is $1\n";
   }

my $spstr2 = 'The dog jumped from the green ?tree';   

if ($spstr2 =~ /\w+.*(\?)tree/) 
   {
    #print "The special character that exists is $1\n";
   }