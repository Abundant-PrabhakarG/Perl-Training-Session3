 use strict;
 use warnings;
 
 my $mystring = "Good Morning!";
 
 $mystring =~ s/Morning/Evening/;
 print "$mystring\n";
 
 #Ignoring case
 $mystring =~ s/morning/Evening/i;
 print "$mystring - case insensitive substituition\n";