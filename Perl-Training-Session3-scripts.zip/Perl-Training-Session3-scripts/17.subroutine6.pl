use strict;
use warnings;

#Declaring a variable
my $variable = 7777;

# Function definition
sub vary { 
   my $funvariable = 8888;
   print "\nThis variable is declared in main script: $variable\n";
   
}

# Function call
vary();
print "\nThis variable is declared in the subroutine: $funvariable\n";

