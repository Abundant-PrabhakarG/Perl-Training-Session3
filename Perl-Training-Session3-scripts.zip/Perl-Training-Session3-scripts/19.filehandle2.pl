use strict;
use warnings; 

open(DATA1, "<import.txt"); # Open file to read
open(DATA2, ">file2.txt"); # Open new file to write
 while(<DATA1>) {
   print DATA2 $_;
}
close( DATA1 );
close( DATA2 );
