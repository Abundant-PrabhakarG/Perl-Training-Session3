use strict;
use warnings; 

open(DATA,"<import.txt") or die "Can't open data";
my @lines = <DATA>;

print @lines;
close(DATA);
