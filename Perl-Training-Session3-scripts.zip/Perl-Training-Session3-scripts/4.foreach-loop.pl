use strict;
use warnings;

my @list = (2, 20, 30, 40, 50);

foreach $a (@list) {
           print "value of a: $a\n";
           }