use strict;
use warnings;

my $str = 'The black cat jumped from the green tree';
if ($str !~ m/dog/) 
   {
    print "There is no dog\n";
   }