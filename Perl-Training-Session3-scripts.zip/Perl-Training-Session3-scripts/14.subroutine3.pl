use strict;
use warnings;

# Function definition
sub PrintList {
   my @list = @_;
   print "Given list is @list\n";
}
my $a = 10;
my @b = (1, 2, 3, 4);

# Function call with list parameter
PrintList($a, @b);